package com.spring.core;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringCoreDataInjection009ApplicationTests {

	@Test
	void contextLoads() {
	}

}
