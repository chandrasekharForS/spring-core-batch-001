package com.spring.core.model;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class Student {
	
	@Value("101")
	private int rollNumber;
	
	@Value("Anish")
	private String studentName;
	
	@Value("Python Full Stack")
	private String courseName;
	
	public int getRollNumber() {
		return rollNumber;
	}
	
	public void setRollNumber(int rollNumber) {
		this.rollNumber = rollNumber;
	}
	
	//public String getStudentName() {
		//return studentName;
	//}
	
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	
	public String getCourseName() {
		return courseName;
	}
	
	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}
	
	public void display() {
		System.out.println("============================");
		System.out.println("Roll Number: " + rollNumber);
		System.out.println("Student Name: " + studentName);
		System.out.println("Course Name: " + courseName);
	}
}
