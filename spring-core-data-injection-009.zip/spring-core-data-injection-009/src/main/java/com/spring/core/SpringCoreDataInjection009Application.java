package com.spring.core;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringCoreDataInjection009Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringCoreDataInjection009Application.class, args);
	}

}
