package com.spring.core.demo;

public class SalaryCalculator {

    private Employee employee;

    public void setEmployee(Employee employee) {
        this.employee = employee;
    }

    public void calculateSalary() {

        double grossSalary =
                employee.getBasicSalary() + employee.getAllowances();

        double netSalary = grossSalary - employee.getDeductions();

        System.out.println("Employee ID: "
                + employee.getEmployeeId());

        System.out.println("Employee Name: "
                + employee.getEmployeeName());

        System.out.println("Basic Salary: "
                + employee.getBasicSalary());

        System.out.println("Allowances: "
                + employee.getAllowances());

        System.out.println("Gross Salary: "
                + grossSalary);

        System.out.println("Deductions: "
                + employee.getDeductions());

        System.out.println("Net Salary: "
                + netSalary);
    }
}

