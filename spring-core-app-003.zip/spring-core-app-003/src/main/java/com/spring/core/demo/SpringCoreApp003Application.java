package com.spring.core.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringCoreApp003Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringCoreApp003Application.class, args);
	}

}
