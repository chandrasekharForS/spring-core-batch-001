package com.spring.core.demo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

	public static void main(String[] args) {
        ApplicationContext context =
                new ClassPathXmlApplicationContext("beans.xml");
        
        SalaryCalculator calculator = 
        		context.getBean("salaryCalculator", SalaryCalculator.class);
        
        calculator.calculateSalary();

	}
}
