package com.spring.core.demo;

public class Employee {
    private int employeeId;
    private String employeeName;
    private double basicSalary;
    private double allowances;
    private double deductions;

    public void setEmployeeId(int employeeId) {
        this.employeeId = employeeId;
    }

    public void setEmployeeName(String employeeName) {
        this.employeeName = employeeName;
    }

    public void setBasicSalary(double basicSalary) {
        this.basicSalary = basicSalary;
    }

    public void setAllowances(double allowances) {
        this.allowances = allowances;
    }

    public void setDeductions(double deductions) {
        this.deductions = deductions;
    }

    public int getEmployeeId() {
        return employeeId;
    }

    public String getEmployeeName() {
        return employeeName;
    }

    public double getBasicSalary() {
        return basicSalary;
    }

    public double getAllowances() {
        return allowances;
    }

    public double getDeductions() {
        return deductions;
    }
}

