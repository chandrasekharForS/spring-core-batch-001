package com.spring.core.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringCoreApp003ApplicationTests {

	@Test
	void contextLoads() {
	}

}
