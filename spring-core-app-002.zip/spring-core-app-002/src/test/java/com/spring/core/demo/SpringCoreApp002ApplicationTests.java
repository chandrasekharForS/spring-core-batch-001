package com.spring.core.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringCoreApp002ApplicationTests {

	@Test
	void contextLoads() {
	}

}
