package com.spring.core.demo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

	public static void main(String[] args) {
		
		ApplicationContext context = 
				new ClassPathXmlApplicationContext("beans.xml");
		
		Addition addition1 = context.getBean("addition1", Addition.class);
		
		addition1.displaySum();
		
		addition1.setNumber1(22);
		addition1.setNumber2(33);
		
		addition1.displaySum();
		
		Addition addition2 = context.getBean("addition2", Addition.class);
		addition2.setNumber1(1);
		addition2.setNumber2(2);
		
		addition2.displaySum();

	}

}
