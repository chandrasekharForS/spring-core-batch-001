package com.spring.core.demo;

public class Addition {

    private int number1;
    private int number2;

    public void setNumber1(int number1) {
        this.number1 = number1;
    }

    public void setNumber2(int number2) {
        this.number2 = number2;
    }

    public void displaySum() {
        int result = number1 + number2;
        System.out.println("First Number: " + number1);
        System.out.println("Second Number: " + number2);
        System.out.println("Sum: " + result);
    }
}
