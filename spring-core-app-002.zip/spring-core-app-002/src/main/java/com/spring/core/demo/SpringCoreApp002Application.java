package com.spring.core.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringCoreApp002Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringCoreApp002Application.class, args);
	}

}
