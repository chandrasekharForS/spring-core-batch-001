package com.spring.core.di;

public class ShoppingCart {
	private Payment payment;
	
	// DI through the constructor
	public ShoppingCart(Payment payment) {
		this.payment = payment;
	}
	
	public void checkOut(double amount) {
		payment.pay(amount);
	}
}
