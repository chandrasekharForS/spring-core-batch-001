package com.spring.core.di;

public class UPIPayment implements Payment {
	@Override
	public void pay(double amount) {
		System.out.println("The amount " + amount + " is paid through the UPI.");
	}
}
