package com.spring.core.di;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringCoreDi006Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringCoreDi006Application.class, args);
	}

}
