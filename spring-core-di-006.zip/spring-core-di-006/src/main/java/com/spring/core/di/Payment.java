package com.spring.core.di;

public interface Payment {
	void pay(double amount);
}
