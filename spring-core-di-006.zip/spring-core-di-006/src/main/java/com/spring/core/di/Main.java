package com.spring.core.di;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

	public static void main(String[] args) {
		
		try(ClassPathXmlApplicationContext context = 
				new ClassPathXmlApplicationContext("beans.xml")) {
			
			ShoppingCart cart = context.getBean("upiCart", ShoppingCart.class);
			cart.checkOut(1500.00);
			
			cart = context.getBean("creditCardCart", ShoppingCart.class);
			cart.checkOut(2500.00);
			
			cart = context.getBean("netBankingCart", ShoppingCart.class);
			cart.checkOut(3500.00);
			
			cart = context.getBean("cashCart", ShoppingCart.class);
			cart.checkOut(4500.00);
			
			cart = context.getBean("giftCardCart", ShoppingCart.class);
			cart.checkOut(5500.00);
		}
		
		/*Payment payment = new UPIPayment();
		
		ShoppingCart cart = new ShoppingCart(payment);
		cart.checkOut(1500);
		
		payment = new CreditCardPayment();
		
		cart = new ShoppingCart(payment);
		cart.checkOut(2500);
		
		payment = new NetBankingPayment();
		
		cart = new ShoppingCart(payment);
		cart.checkOut(3500);
		
		payment = new CashPayment();
		
		cart = new ShoppingCart(payment);
		cart.checkOut(4500);
		
		payment = new GiftCardPayment();
		
		cart = new ShoppingCart(payment);
		cart.checkOut(5500);
		*/
		
	}
}
