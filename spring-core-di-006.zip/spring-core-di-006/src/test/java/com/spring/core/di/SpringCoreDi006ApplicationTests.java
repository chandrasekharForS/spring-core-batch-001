package com.spring.core.di;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringCoreDi006ApplicationTests {

	@Test
	void contextLoads() {
	}

}
