package com.spring.core.lc;

public class NetBankingPayment implements Payment {
	@Override
	public void pay(double amount) {
		System.out.println("The amount " + amount + " is paid through the Net Banking.");
	}
}
