package com.spring.core.lc;

public class Main {

	public static void main(String[] args) {
		
		Payment payment = new UPIPayment();
		
		ShoppingCart cart = new ShoppingCart(payment);
		cart.checkOut(1500);
		
		payment = new CreditCardPayment();
		
		cart = new ShoppingCart(payment);
		cart.checkOut(2500);
		
		payment = new NetBankingPayment();
		
		cart = new ShoppingCart(payment);
		cart.checkOut(3500);
		
		payment = new CashPayment();
		
		cart = new ShoppingCart(payment);
		cart.checkOut(4500);
		
		payment = new GiftCardPayment();
		
		cart = new ShoppingCart(payment);
		cart.checkOut(5500);
	}
}
