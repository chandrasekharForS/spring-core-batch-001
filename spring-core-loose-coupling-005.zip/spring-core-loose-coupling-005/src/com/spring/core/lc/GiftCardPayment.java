package com.spring.core.lc;

public class GiftCardPayment implements Payment {

	@Override
	public void pay(double amount) {
		System.out.println("The amount " + amount + " is paid through the Gift Card.");
	}

}
