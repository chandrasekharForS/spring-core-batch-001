package com.spring.core.lc;

public interface Payment {
	void pay(double amount);
}
