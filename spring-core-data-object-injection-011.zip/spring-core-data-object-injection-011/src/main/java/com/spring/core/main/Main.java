package com.spring.core.main;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.spring.core.config.AppConfig;
import com.spring.core.model.BankAccount;

public class Main {

	public static void main(String[] args) {
		try(AnnotationConfigApplicationContext context = 
				new AnnotationConfigApplicationContext(AppConfig.class)) {
			
			BankAccount account = context.getBean(BankAccount.class);
			
			account.display();
		}
	}
}
