package com.spring.core.model;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class Customer {
	@Value("101")
	private int customerId;
	
	@Value("Mahesh")
	private String customerName;
	
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	
	
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	
	public void display() {
		System.out.println("======================================");
		System.out.println("Customer ID: " + customerId);
		System.out.println("Customer Name: " + customerName);
	}
	
}
