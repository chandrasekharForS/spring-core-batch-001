package com.spring.core;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringCoreDataObjectInjection011Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringCoreDataObjectInjection011Application.class, args);
	}

}
