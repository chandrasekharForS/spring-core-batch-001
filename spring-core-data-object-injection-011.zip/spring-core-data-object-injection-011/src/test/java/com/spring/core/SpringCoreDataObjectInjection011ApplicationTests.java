package com.spring.core;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringCoreDataObjectInjection011ApplicationTests {

	@Test
	void contextLoads() {
	}

}
