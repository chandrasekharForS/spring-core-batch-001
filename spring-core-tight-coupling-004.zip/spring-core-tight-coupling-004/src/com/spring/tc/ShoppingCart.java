package com.spring.tc;

public class ShoppingCart {
	private UPIPayment upiPayment;
	private CreditCardPayment creditCardPayment;
	private NetBankingPayment netBankingPayment;
	private CashPayment cashPayment; 
	
	public ShoppingCart() {
		upiPayment = new UPIPayment();
		creditCardPayment = new CreditCardPayment();
		netBankingPayment = new NetBankingPayment();
		cashPayment = new CashPayment();
	}
	
	public void checkOut(String paymentType, double amount) {
		if(paymentType.equals("UPI"))
			upiPayment.pay(amount);
		else if(paymentType.equals("CREDIT_CARD"))
			creditCardPayment.pay(amount);
		else if(paymentType.equals("NET_BANKING"))
			netBankingPayment.pay(amount);
		else if(paymentType.equals("CASH"))
			cashPayment.pay(amount);
		else
			System.out.println("You have given wrong type of payment method.");
	}
}
