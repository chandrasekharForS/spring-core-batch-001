package com.spring.tc;

public class Main {

	public static void main(String[] args) {
		ShoppingCart cart = new ShoppingCart();
		
		cart.checkOut("UPI", 1500.00);
		cart.checkOut("CREDIT_CARD", 2500);
		cart.checkOut("NET_BANKING", 3500);
		cart.checkOut("CASH", 4500);
	}
}
