package com.spring.tc;

public class CreditCardPayment {
	public void pay(double amount) {
		System.out.println("The amount " + amount + " is paid through the Credit Card.");
	}
}
