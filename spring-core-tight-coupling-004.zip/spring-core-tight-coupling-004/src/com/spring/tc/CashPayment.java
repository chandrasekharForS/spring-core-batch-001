package com.spring.tc;

public class CashPayment {
	public void pay(double amount) {
		System.out.println("The amount " + amount + " is paid through the Cash.");
	}
}
