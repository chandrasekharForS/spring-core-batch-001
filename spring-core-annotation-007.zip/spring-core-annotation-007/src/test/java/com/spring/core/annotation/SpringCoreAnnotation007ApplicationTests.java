package com.spring.core.annotation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringCoreAnnotation007ApplicationTests {

	@Test
	void contextLoads() {
	}

}
