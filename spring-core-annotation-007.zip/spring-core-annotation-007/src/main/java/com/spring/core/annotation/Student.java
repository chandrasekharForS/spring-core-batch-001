package com.spring.core.annotation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class Student {
	private ResultService resultService = null;
	
	@Autowired
	public Student(ResultService resultService) {
		this.resultService = resultService;
	}
	
	public void viewResult() {
		resultService.displayResult("Ravi Kumar", 25);
	}
}
