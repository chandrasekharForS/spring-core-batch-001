package com.spring.core.annotation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringCoreAnnotation007Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringCoreAnnotation007Application.class, args);
	}

}
