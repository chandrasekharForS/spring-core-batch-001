package com.spring.core.annotation;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Main {

	public static void main(String[] args) {
		try(AnnotationConfigApplicationContext context  =
				new AnnotationConfigApplicationContext(CollegeConfig.class)) {
			
			Student student = context.getBean(Student.class);
			student.viewResult();
		}

	}

}
