package com.spring.core.annotation;

import org.springframework.stereotype.Service;

@Service
public class ResultService {
	public void displayResult(String studentName, double marks) {
		System.out.println("Student Name: " + studentName);
		System.out.println("Marks: " + marks);
		
		if(marks >= 40)
			System.out.println("Result: PASS.");
		else
			System.out.println("Result: FAIL.");
	}
}
