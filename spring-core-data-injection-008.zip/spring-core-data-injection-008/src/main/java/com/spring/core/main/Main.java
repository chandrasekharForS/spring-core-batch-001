package com.spring.core.main;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.spring.core.model.Student;

public class Main {

	public static void main(String[] args) {
		try(ClassPathXmlApplicationContext context = 
				new ClassPathXmlApplicationContext("beans.xml")){
			
			Student student = context.getBean("student", Student.class);
			student.display();

		}

	}

}
