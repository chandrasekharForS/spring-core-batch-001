package com.spring.core.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringCoreApp001Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringCoreApp001Application.class, args);
		System.out.println("Welcome to Spring core programming.");
	}

}
