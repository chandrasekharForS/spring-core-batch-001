package com.spring.core.main;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.spring.core.model.BankAccount;

public class Main {

	public static void main(String[] args) {
		try(ClassPathXmlApplicationContext context = 
				new ClassPathXmlApplicationContext("beans.xml")){
			
			BankAccount account = context.getBean("bankAccount", BankAccount.class);
			
			account.display();
			
		}

	}

}
