package com.spring.core.model;

public class Customer {
	private int customerId;
	private String customerName;
	
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	
	
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	
	public void display() {
		System.out.println("======================================");
		System.out.println("Customer ID: " + customerId);
		System.out.println("Customer Name: " + customerName);
	}
	
}
