package com.spring.core;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringCoreDataObjectInjection010Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringCoreDataObjectInjection010Application.class, args);
	}

}
